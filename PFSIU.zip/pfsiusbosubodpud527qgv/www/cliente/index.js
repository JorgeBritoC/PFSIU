// Umbral para considerar que el dispositivo se ha agitado

const shakeThreshold = 15;
let lastX = null, lastY = null, lastZ = null;

window.addEventListener('devicemotion', function(event) {
    let x = event.accelerationIncludingGravity.x;
    let y = event.accelerationIncludingGravity.y;
    let z = event.accelerationIncludingGravity.z;

    if (lastX !== null && lastY !== null && lastZ !== null) {
        let deltaX = Math.abs(lastX - x);
        let deltaY = Math.abs(lastY - y);
        let deltaZ = Math.abs(lastZ - z);

        if (deltaX > shakeThreshold && deltaY > shakeThreshold || deltaX > shakeThreshold && deltaZ > shakeThreshold || deltaY > shakeThreshold && deltaZ > shakeThreshold) {
            // Lógica para empezar a reconocer la canción
            recognizeSong();
        }
    }

    lastX = x;
    lastY = y;
    lastZ = z;
});

function handleOrientation(event) {
    const z = event.alpha; // orientación alrededor del eje Z
    const y = event.beta;  // orientación alrededor del eje Y
    const x = event.gamma; // orientación alrededor del eje X

    // Detectar giros significativos a la derecha o a la izquierda
    if (x > 20) {  // Ajustar umbral según necesidad
        addToPlaylist();
        window.removeEventListener('deviceorientation', handleOrientation);
    } else if (x < -20) {
        discardSong();
        window.removeEventListener('deviceorientation', handleOrientation);
    }
}

const availableSongs = [
    { title: "Imagine", artist: "John Lennon" },
    { title: "Billie Jean", artist: "Michael Jackson" }
];

let playlist = []; // Array para almacenar las canciones

function updatePlaylist(song) {
    playlist.push(song); // Añade la canción al array de playlist
    renderPlaylist(); // Actualiza la visualización de la playlist
}

function recognizeSong() {
    const randomIndex = Math.floor(Math.random() * availableSongs.length);
    const song = availableSongs[randomIndex];
    displaySongInfo(song.title, song.artist);
}

function displaySongInfo(title, artist) {
    const infoElement = document.getElementById('song-info');
    infoElement.innerHTML = `Reconocida: ${title} de ${artist}`;
    setupActionButtons(title, artist);
}

function setupActionButtons(title, artist) {
    const actionElement = document.getElementById('action-buttons');
    actionElement.innerHTML = `
        <button onclick="addToPlaylist('${title}', '${artist}')">Añadir a la Playlist</button>
        <button onclick="discardSong()">Descartar</button>`;
}

function addToPlaylist(title, artist) {
    const song = { title, artist };
    if (playlist.some(s => s.title === song.title && s.artist === song.artist)) {
        document.getElementById('message').innerText = "La canción ya está en la playlist.";
    } else {
        playlist.push(song);
        document.getElementById('message').innerText = "Canción añadida a la playlist.";
        renderPlaylist();
    }
}

function discardSong() {
    document.getElementById('message').innerText = "Canción descartada.";
}

function renderPlaylist() {
    const playlistElement = document.getElementById('playlist');
    playlistElement.innerHTML = '';
    playlist.forEach((song, index) => {
        playlistElement.innerHTML += `<li>${song.title} - ${song.artist}
            <button onclick="removeFromPlaylist(${index})">Eliminar</button>
            <button onclick="markAsFavorite(${index})">Favorito</button>
        </li>`;
    });
}

function removeFromPlaylist(index) {
    playlist.splice(index, 1);
    renderPlaylist();
}

function markAsFavorite(index) {
    const item = document.querySelector(`#playlist li:nth-child(${index + 1})`);
    item.classList.toggle('favorite');
}

