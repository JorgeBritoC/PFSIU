const socket = io();

const qrcode = new QRCode("qrcode", {
    text: "https://a5c88602-0c6a-4368-89a0-b13857f5534a-00-1n9kcps512pc2.kirk.replit.dev/cliente/cliente.html", 
    width: 512,
    height: 512,
    colorDark: "#000000",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.H
});

socket.on("connect", () => {
    console.log("Conectado al servidor desde el cliente"); // Depuración: confirmar conexión
    socket.emit("CLIENT_CONNECTED", { id: 1 });

    socket.on("ACK_CONNECTION", () => {
        console.log("ACK_CONNECTION recibido en el cliente"); 
    });
});
