const express = require('express');
const app = express();
const path = require('path');
const server = require('http').Server(app);
const io = require('socket.io')(server);

// Sirve los archivos estáticos de la carpeta 'www'
app.use('/', express.static(path.join(__dirname, 'www')));

let clientSocket;

io.on('connection', (socket) => {
  console.log(`socket connected ${socket.id}`);

  // Este evento se activa cuando un cliente se conecta específicamente para interactuar
  socket.on("CLIENT_CONNECTED", () => {
    clientSocket = socket;
    console.log("CLIENT_CONNECTED: Cliente principal conectado.");
    // Emitir un evento para confirmar la conexión
    clientSocket.emit("ACK_CONNECTION");
  });
});

// Escuchar en el puerto 3000
server.listen(3000, () => {
  console.log("Server listening...");
});
